package com.neranjana.tryout.microservices.TimeService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TimeServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
